import React from 'react'
// import './Main.css'
const Loader = () => {
  return (
    <div className='loader'>
      <img src='/images/loader1.gif' alt='Loading' />
    </div>
  )
}

export default Loader
